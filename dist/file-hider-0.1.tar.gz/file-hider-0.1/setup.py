from setuptools import setup

setup(
    name='file-hider',
    version='0.1',
    description='A library for hiding files in jpeg files',
    author='Olger Chotza',
    author_email='olgerdev@icloud.com',
    py_modules=['file_hider'],
)
